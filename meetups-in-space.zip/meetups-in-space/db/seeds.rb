# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Example:
#
#   Person.create(first_name: 'Eric', last_name: 'Kelly')

User.create(
	uid: "1",
	provider: "test_provider",
	username: "test_username",
	email: "test_email",
	avatar_url: "www.google.com"
)

Meetup.create(
	mid: "1",
	name: "test_name",
	location: "test_location",
	creator: "test_creator",
	description: "test_description"
)