class Meetup < ActiveRecord::Base
end